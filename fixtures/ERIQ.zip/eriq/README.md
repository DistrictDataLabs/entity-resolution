This data set is from [UALR Center for Entity Resolution and Information Quality](http://ualr.edu/eriq/downloads/). Part of the Fellegi-Sunter exercise data.
